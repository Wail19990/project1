<?php include("header.php"); ?>

<div class="log_container">
   
    <div class="form_section">
        <div class="form_content">
            <h1>Login</h1>

            <?php
            if (isset($_GET['login'])) {
                if ($_GET['login'] == 'failed') {
                    echo '  <div class="error_login">
                                        <p> Wrong Password or Username</p>
                                    </div>';
                }
            }
            ?>
            <form method="post">
                <div class="form_input">
                    <input type="text" name="username" required>
                    <label>
                        <span>username</span>
                    </label>
                </div>

                <div class="form_input">
                    <input type="password" name="password" required>
                    <label>
                        <span>password</span>
                    </label>
                    <div class="show_pass">
                        <i class="fas fa-eye"></i>
                    </div>
                </div>

                <input type="submit" name="login" value="Login"><br>
            </form>
        </div>
    </div>
</div>

<?php

$bd = new BD();
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if ($bd->isAgent($username, $password)){
        $_SESSION['username'] = $username;
        header("location:agents/index.php");
    }
    else{

        if ($bd->isClient($username, $password)) {
            $_SESSION['username'] = $username;
            header("location:clients/index.php");
        } 
        else {
            header("location:login.php?login=failed");
        }
    }
    
}

?>
<script>
var showpass_btn = document.querySelector(".show_pass i");
var input = document.querySelector("form input[type='password']");
var eye_show = "fa-eye";
var no_eye_show = "fa-eye-slash";

if (showpass_btn) {
    showpass_btn.addEventListener("click", function () {
        showpass_btn.classList.toggle(eye_show);
        showpass_btn.classList.toggle(no_eye_show);
        if (input.type == "password") {
            input.type = "text";
        } else {
            input.type = "password";
        }
    });
}

</script>
</body>
</html>