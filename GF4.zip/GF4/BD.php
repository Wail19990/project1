<?php
class BD
{


    public function bd()
    {
        $dbh = new PDO('mysql:host=localhost;dbname=gestion_factures', 'root', '');
        return  $dbh;
    }

    /** ------------------------------------- Systeme ---------------------------------- */

    public function isAgent($cin, $password)
    {
        $dbh = $this->bd();
        $query = 'SELECT`password` FROM `agents` WHERE `cin`=:cin';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":cin" => $cin));
        $count = $stmt->rowCount();
        $result = $stmt->fetchAll();
        if ($count > 0) {
            if (password_verify($password, $result[0][0])) {
                return true;
            }
        }

        return false;
    }

    public function isClient($num, $password)
    {
        $dbh = $this->bd();
        $query = 'SELECT `password` FROM `clients` INNER JOIN `contrats` ON contrats.cin_client = clients.cin
        WHERE contrats.num_contrat = :num';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $count = $stmt->rowCount();
        $result = $stmt->fetchAll();
        if ($count > 0) {
            if (password_verify($password, $result[0][0])) {
                return true;
            }
        }

        return false;
    }


    /**-- get client information -- */

    public function ClientName($num_contrat)
    {
        $dbh = $this->bd();

        $query = 'SELECT nom , prenom FROM `clients` INNER join contrats on contrats.cin_client = clients.cin where num_contrat =:num_contrat ';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num_contrat" => $num_contrat));
        $result = $stmt->fetchAll();

        foreach ($result as $n)
            echo $n[0] . ' ' . $n[1];
    }
    public function showClient()
    {
        $dbh = $this->bd();

        $query = "SELECT  `cin`,`nom`, `prenom`, `email`, `telephone` FROM `clients`";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array());
        $result = $stmt->fetchAll();
        if ($result) {
            foreach ($result as $i) {
                echo '
        <tr>
                <td>' . $i[0] . '</td>
                <td>' . $i[1] . '</td>
                <td>' . $i[2] . '</td>
                <td>' . $i[3] . '</td>
                <td>' . $i[4] . '</td>
                <td>
                    <form action="client.php?update=start&&id=' . $i[0] . '" method = "post" class="table-btn">
                        <button type="submit" name="update" class ="fas fa-user-edit"> </button>   
                    </form>
                </td>
                <td>
                    <form  method = "post" class="table-btn">
                        <input type="hidden" value="' . $i[0] . '" name="cin">
                        <button type="submit" name="delete" class ="fas fa-user-times"  onclick = "if ( !confirm(\'Êtes vous sûr de vouloir supprimer le client (la contrat et tout les factures seront supprimé)  ?\')) return false;"> </button>   
                    </form>
                
                </td>
            </tr>
        ';
            }
        } else {
            echo '<tr>
            <td colspan="7">Pas des donnees</td>
        </tr>';
        }
    }
    /** les donnees d'un client  */
    public function showClientId($cin)
    {

        $dbh = $this->bd();
        $query = "SELECT * FROM `clients` WHERE `cin` = :cin";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":cin" => $cin));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0];
    }
    /** l'email d'un client */
    public function getEmail($numContrat)
    {
        $dbh = $this->bd();
        $query = "SELECT `email` FROM `clients` INNER JOIN `contrats` WHERE contrats.num_contrat  =:num";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $numContrat));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
    }

    /**-- Dashboard -- */



    /** consomation du  Dernier mois */
    public function lastMonth($num)
    {
        $dbh = $this->bd();

        $query = 'SELECT `date_facture` FROM `facture` WHERE num_contrat =:num ORDER BY date_facture DESC LIMIT 1';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
    }

    /** calcule de la consommation annuelle */
    public function consommationAnuelle($num)
    {
        $dbh = $this->bd();

        $query = 'SELECT `consommation` FROM `facture` WHERE num_contrat =:num
        ORDER BY date_facture DESC LIMIT 12';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        $somme = 0;
        foreach ($result as $row) {
            $somme += $row[0];
        }
        return $somme;
    }

    /** calcule de la consommation annuelle de l'annee dernier*/
    public function consommationAnneeDernier($num)
    {
        $dbh = $this->bd();

        $last = date_create($this->lastMonth($num));
        date_sub($last, date_interval_create_from_date_string("365 days"));

        $beforeLast = date_create($this->lastMonth($num));
        date_sub($beforeLast, date_interval_create_from_date_string("730 days"));


        $query = "SELECT SUM(consommation) FROM facture  WHERE num_contrat =:num AND date_facture BETWEEN  :BeforeLastYear AND :lastYear ";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num, ":BeforeLastYear" => date_format($beforeLast, "Y-m-d"), ":lastYear" => date_format($last, "Y-m-d")));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
    }

    /** calcule de la consommation mensuel */
    public function consommationMensuel($num)
    {
        $dbh = $this->bd();

        $query = 'SELECT `consommation` FROM `facture` WHERE num_contrat =:num
        ORDER BY date_facture DESC LIMIT 1';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
        else return 0;
    }

    /** calcule de la differance de consommation mensuel  */
    public function TauxConsommationMensuel($num)
    {
        $dbh = $this->bd();
        $query = 'SELECT `consommation` FROM `facture` WHERE num_contrat =:num
        ORDER BY date_facture DESC LIMIT 2';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        if (!empty($result))
            return round(($result[0][0] - $result[1][0]), 2);
        else return 0;
    }

    /** calcule de la differance de consommation annuel  */
    public function TauxConsommationAnnuel($num)
    {
        $thisYear = $this->consommationAnuelle($num);

        $lastYear = $this->consommationAnneeDernier($num);

        return round($lastYear - $thisYear, 2);
    }

    /** -- chart data -- */
    public function chart($num)
    {
        $dbh = $this->bd();

        $query = 'SELECT `date_facture`, `consommation` FROM `facture` WHERE num_contrat =:num
        ORDER BY date_facture DESC LIMIT 12';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        return $result;
    }

    /** --  verifier la Consomation entrer par le client-- */
    public function CalculeConsomation($total)
    {
        $dbh = $this->bd();
        $query = 'SELECT num_compteur from facture ORDER by date_facture DESC LIMIT 1';
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        if (!empty($result)) {
            if ($total < $result[0])
                return -1;
            else
                return $total - $result[0];
        }
    }

    /** --  calcule de la consommation de la fin d'annee -- */
    public function CalculeConsomationEndOfYear($total)
    {
        $dbh = $this->bd();
        $query = 'SELECT num_compteur from facture ORDER by date_facture DESC LIMIT 1';
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();

        if (!empty($result))
            return $total - $result[0];
        else
            $total;
    }

    /** -- calcule prix HT -- */
    public function prixHT($consommation)
    {

        $prixHT = 0;
        if ($consommation <= 100)
            $prixHT = 0.91 * $consommation;
        elseif ($consommation <= 200)
            $prixHT = 1.01 * $consommation;
        else
            $prixHT = 1.12 * $consommation;
        return $prixHT;
    }


    /** -- factures -- */
    public function countFacture($num)
    {
        $dbh = $this->bd();

        $query = "SELECT COUNT(`num_facture`) FROM `facture` WHERE `num_contrat` = :num AND statut = 'non reglé'";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();

        if (!empty($result))
            return $result[0][0];
        else 0;
    }

    public function checkDateFacture($date)
    {
        $dbh = $this->bd();
        $query = 'SELECT date_facture from facture ORDER by date_facture DESC LIMIT 1';
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch();
        if ($date < $result[0] || substr($date, 0, 7) == substr($result[0], 0, 7)) {
            echo "<script>window.location='consomation.php?addDate=failed'</script>";
            return -1;
        } else {
            return 0;
        }
    }


    public function showFacture($num)
    {
        $dbh = $this->bd();

        $query = "SELECT num_facture, date_facture, consommation, prix_HT, prix_TTC,statut,facture.num_contrat,nom,prenom
        FROM facture 
        INNER JOIN contrats ON facture.num_contrat = contrats.num_contrat
        INNER JOIN clients ON clients.cin = contrats.cin_client
        WHERE facture.num_contrat =:num AND statut = 'non reglé'";

        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();
        $j = 0;

        if (!empty($result)) {
            foreach ($result as $i) {
                echo '
            <tr>
                <td>' . $i[0] . '</td>
                <td>' . $i[1] . '</td>
                <td>' . $i[2] . '</td>
                <td>' . $i[3] . '</td>
                <td>' . $i[4] . '</td>
                <td>' . $i[5] . '</td>
                <td><i class="fas fa-check-circle showFacture icon-table" show="' . $j . '"></i></td>
                
                    <div class="modal-container fadeOut" id="modal">
                        <div class="modal-form">
                            <div class="up">
                                <i class="fas fa-times-circle closeFacture" show="' . $j++ . '"></i>
                            </div>
                            <div class="center">

                                <div class="info">
                                    <h3>Numero de facture</h3>
                                    <span>' . $i[0] . '</span>
                                </div>
                                <div class="info">
                                    <p>Date de facture</p>
                                    <span>' . $i[1] . '</span>
                                </div>
                                <div class="info">
                                    <p>Numero de contart</p>
                                    <span>' . $i[6] . '</span>
                                </div>
                                <div class="info">
                                    <p>Nom</p>
                                    <span>' . $i[7] . '</span>
                                </div>
                                <div class="info">
                                    <p>Prenom</p>
                                    <span>' . $i[8] . '</span>
                                </div>
                                <div class="info">
                                    <p>Consomation</p>
                                    <span>' . $i[2] . ' KW/H</span>
                                </div>
                                <div class="info">
                                    <p>Prix</p>
                                    <span>' . $i[4] . ' Dh</span>
                                </div>
                            </div>

                            <div class="down">
                            <form action="../mypdf.php" method="post">
                             <input type ="hidden" name="numFact" value="' . $i[0] . '">   
                             <input type ="hidden" name="dateFact" value="' . $i[1] . '">   
                             <input type ="hidden" name="numCont" value="' . $i[6] . '">   
                             <input type ="hidden" name="nom" value="' . $i[7] . '">   
                             <input type ="hidden" name="prenom" value="' . $i[8] . '">   
                             <input type ="hidden" name="cons" value="' . $i[2] . '">   
                             <input type ="hidden" name="prix" value="' . $i[4] . '">  
                             <button type ="submit" name="down"> <i class="fas fa-download"></i> Download</button>
                            </form>
                            </div>

                        </div>
                    </div>
            </tr>';
            }
        } else {
            echo '<tr>
                <td colspan="7">Pas des donnees</td>
            </tr>';
        }
    }




    /** ------------------------------------- Clients ------------------------------------- */
    /** -- Ajouter facture -- */

    public function insertFacture($num, $date, $total)
    {
        $dbh = $this->bd();
        $date = substr($date, 0, 8) . "01";
        $consommation = $this->CalculeConsomation($total);
        $checkDate = $this->checkDateFacture($date);
        if ($consommation == -1)
            echo "<script>window.location='consomation.php?add=failed'</script>";
        elseif ($checkDate == 0) {
            $prixHT = $this->prixHT($consommation);
            $prixTTC = $prixHT * 1.14;
            $stat = 'non reglé';

            $debit = $this->getDebit($num);
            if ($debit >= 0) {
                $prixTTC = max($prixTTC - $debit, 0);
                $newDebit = max(0, $debit - $prixTTC);
                $this->UpdateDebit($num, $newDebit);
            } else {
                $prixTTC += abs($debit);
                $this->UpdateDebit($num, 0);
            }


            $query = 'INSERT INTO `facture`(`num_contrat`, `date_facture`,`num_compteur`,  `consommation`, `prix_HT`, `prix_TTC`,`statut`) VALUES (:num,:datefacture,:total,:consommation,:pht,:pttc,:stat)';
            $stmt = $dbh->prepare($query);
            $stmt->execute(array(":num" => $num, ":datefacture" => $date, ":total" => $total, ":consommation" => $consommation, ":pht" => $prixHT, ":pttc" => $prixTTC, ":stat" => $stat));
            echo "<script>window.location='facture.php'</script>";
        }
    }

    /** -- Ajouter reclamation -- */
    public function insertReclamation($num_contrat, $object, $reclamation)
    {
        $dbh = $this->bd();
        $stat = 'non reglé';

        $query = 'INSERT INTO `reclamation`(`num_contrat`,`num_agent`, `object`, `reclamation`,`date_reclamation`,`statut`) VALUES (:num_contrat,0,:email,:reclamation,:date_reclamation,:stat)';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num_contrat" => $num_contrat, ":email" => $object, ":reclamation" => $reclamation, ":date_reclamation" => date('Y-m-d'), ":stat" => $stat));
        echo "<script>window.location='reclamation.php?send=success'</script>";
    }


    /*------------------------------------------ Agents -----------------------------*/
    /**-- get agent information -- */

    public function agentName($cin)
    {
        $dbh = $this->bd();

        $query = 'SELECT nom , prenom FROM `agents` where cin =:cin ';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":cin" => $cin));
        $result = $stmt->fetchAll();

        foreach ($result as $n)
            echo $n[0] . ' ' . $n[1];
    }
    /** ajouter client */
    public function insertClient($nom, $prenom, $cin, $email, $telephone)
    {
        $dbh = $this->bd();
        $query = 'INSERT INTO `clients`(`nom`, `prenom`, `cin`, `email`, `telephone`,`password`) VALUES (:nom , :prenom ,:cin ,:email , :telephone,:pass)';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":nom" => $nom, ":prenom" => $prenom, ":cin" => $cin, ":email" => $email, ":telephone" => $telephone, ":pass" => password_hash($cin, PASSWORD_DEFAULT)));
        $this->insertContrat($cin, date('Y-m-d'));
        echo "<script>window.location='client.php?add=success'</script>";
    }
    /** modifier client */

    public function updateClient($cin, $newNom, $newPrenom, $newCin, $newEmail, $newTelephone)
    {
        $dbh = $this->bd();
        $query = 'UPDATE `clients` SET `nom`=:newNom,`prenom`=:newPrenom,`cin`=:newCin,`email`=:newEmail,`telephone`=:newTelephone WHERE `cin` = :cin';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":newNom" => $newNom, ":newPrenom" => $newPrenom, ":newCin" => $newCin, ":newEmail" => $newEmail, ":newTelephone" => $newTelephone, ":cin" => $cin));
        echo "<script>window.location='client.php?update=success'</script>";
    }

    /** suprimer  client */

    public function deleteClient($cin)
    {
        $dbh = $this->bd();
        $query = 'DELETE FROM `clients` WHERE `cin` =:cin';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":cin" => $cin));
        echo "<script>window.location='client.php'</script>";
    }

    /** ajouter Contrat */
    public function insertContrat($cin, $date)
    {
        $dbh = $this->bd();
        $query = 'INSERT INTO `contrats`(`date_contrat`, `cin_client`, `debit`) VALUES (:dateC,:cinClient,0)';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":dateC" => $date, ":cinClient" => $cin));
    }

    /** modifier statut de la facture */
    public function updateStatut($numFacture)
    {
        $dbh = $this->bd();
        $query = "UPDATE `facture` SET `statut`= 'reglé' WHERE  num_facture =:num_facture";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num_facture" => $numFacture));
    }

    /** Afficher les reclamations **/
    public function showReclamation()
    {
        $dbh = $this->bd();

        $query = "SELECT `num_contrat`, `object`, `reclamation`, `date_reclamation`, `statut`,`num_reclam` FROM `reclamation` WHERE `statut` = 'non reglé'";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array());
        $result = $stmt->fetchAll();

        if ($result) {
            foreach ($result as $i) {

                echo '
            <tr>
                    <td>' . $i[0] . '</td>
                    <td>' . $i[1] . '</td>
                    <td>' . $i[2] . '</td>
                    <td>' . $i[3] . '</td>
                    <td>' . $i[4] . '</td>
            
                    <td>
                        <form action="" method="POST" class="table-btn">
                            <input type="hidden" value="' . $i[5] . '" name="numRec">
                            <button type="submit" class=" fas fa-reply" name="reply">
                        </form>
                    </td>
                </tr>';
            }
        } else {
            echo '<tr>
                <td colspan="6">Pas des donnees</td>
            </tr>';
        }
    }

    /** modifier reclamation */
    public function updateReclamation($num, $cinAgent, $dateReponse)
    {

        $dbh = $this->bd();
        $query = 'UPDATE `reclamation` SET `num_agent`=:cinAgent,`date_reponse`=:dateReponse,`statut`="reglé" WHERE `num_reclam`=:num';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":cinAgent" => $cinAgent, ":dateReponse" => $dateReponse, ":num" => $num));

        echo "<script>window.location='reclamation.php?id=" . $num . "'</script>";
    }

    public function sendEmail($num)
    {
        $dbh = $this->bd();

        $query = "SELECT `num_contrat`, `object` FROM `reclamation` WHERE `num_reclam` =:num";
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num));
        $result = $stmt->fetchAll();

        if (!empty($result))
            echo "<script>window.location='mailto:" . $this->getEmail($result[0][0]) . "?subject=" . $result[0][1] . "'</script>";
    }

    /*** get la veleur de debit */
    public function getDebit($num_contrat)
    {
        $dbh = $this->bd();
        $query = 'SELECT `debit` FROM `contrats` WHERE `num_contrat`=:num';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":num" => $num_contrat));
        $result = $stmt->fetchAll();
        return $result[0][0];
    }

    /*** modifier le debit pour chaque client */
    public function UpdateDebit($num_contrat, $debit)
    {
        $dbh = $this->bd();
        $query = 'UPDATE `contrats` SET `debit`=:debit WHERE `num_contrat`=:num';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":debit" => $debit, ":num" => $num_contrat));
    }

    /*** affichage des consomations */
    public function showConsomation()
    {
        $dbh = $this->bd();
        $query = 'SELECT facture.num_contrat,SUM(consommation) 
        FROM facture 
        INNER JOIN contrats ON contrats.num_contrat = facture.num_contrat 
        WHERE year(date_facture)>=year(SYSDATE()) AND year(date_facture)<year(SYSDATE())+1
        GROUP BY facture.num_contrat ';

        $stmt = $dbh->prepare($query);
        $stmt->execute(array());
        $result = $stmt->fetchAll();
        if ($result) {
            foreach ($result as $i) {
                echo '
            <tr>
                <td>' . $i[0] . '</td>
                <td>' . $i[1] . '</td>';

                if (file_exists("../docs/consomation_" . date('Y') . ".txt")) {
                    $file = fopen("../docs/consomation_" . date('Y') . ".txt", "r");
                    while (!feof($file)) {
                        $line = fgets($file);
                        $id = substr($line, 0, strpos($line, ":"));
                        if ($id == $i[0]) {
                            $cons = substr($line, strpos($line, ":") + 1);

                            echo '<td>' . $cons . '</td>';
                            echo '<td>';

                            if ($cons == $i[1])
                                echo "<i class='fas fa-equals'></i>";

                            if ($cons > $i[1])
                                echo "<i class='fas fa-less-than red'></i>";

                            if ($cons < $i[1])
                                echo "<i class='fas fa-greater-than green'></i>";

                            echo '</td>';
                        }
                    }
                    fclose($file);
                } else {
                    echo '<td colspan="2">No data</td>';
                }
                echo    ' </tr>';

                //update debit
                $olddebit = $this->getDebit($i[0]);
                $newdebit = $this->prixHT($i[1] - $cons) * 1.14;

                $this->UpdateDebit($i[0], $olddebit + $newdebit);
            }
        } else {
            echo '<tr>
                <td colspan="4">Pas des donnees</td>
            </tr>';
        }
    }

    /*-----------------------Dashboard-Agent----------------------*/
    //nombre de reclamation non regle ----
    public function countReclamation()
    {
        $dbh = $this->bd();
        $query = "SELECT COUNT(*) FROM `reclamation` WHERE statut = 'non reglé'";
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
        else
            return 0;
    }

    /// graphe nombre dereclamation kitla3o kinzel ---------

    public function chartNumeroReclamation()
    {
        $dbh = $this->bd();
        $query = 'SELECT MONTH( date_reclamation), COUNT(*) FROM reclamation WHERE date_reclamation IN( SELECT date_reclamation FROM reclamation WHERE date_reclamation <=:d AND date_reclamation > :l ) GROUP BY MONTH( date_reclamation) ORDER BY date_reclamation';
        $stmt = $dbh->prepare($query);
        $stmt->execute(array(":d" => date('Y-m-d'), ":l" => date((date("Y") - 1) . date("-m-d"))));
        $result = $stmt->fetchAll();
        return $result;
    }

    /// nombre des clients ajouter cette annee
    public function nbClientAjouter()
    {
        $dbh = $this->bd();
        $query = 'SELECT COUNT(*) FROM clients INNER JOIN contrats ON clients.cin = contrats.cin_client WHERE year(date_contrat)>="' . date("Y") . '" AND year(date_contrat)<"' . date(date("Y") + 1) . '"';
        $stmt = $dbh->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll();
        if (!empty($result))
            return $result[0][0];
        else return 0;
    }

    //taux de client qui entrent les donnees verifiees
    public function nbClientTrust()
    {
        $dbh = $this->bd();

        $query = 'SELECT facture.num_contrat,SUM(consommation) 
        FROM facture 
        INNER JOIN contrats ON contrats.num_contrat = facture.num_contrat 
        WHERE year(date_facture)>=year(SYSDATE()) AND year(date_facture)<year(SYSDATE())+1
        GROUP BY facture.num_contrat ';

        $stmt = $dbh->prepare($query);
        $stmt->execute(array());
        $result = $stmt->fetchAll();

        $trust = 0;

        foreach ($result as $i) {

            if (file_exists("../docs/consomation_" . date('Y') . ".txt")) {
                $file = fopen("../docs/consomation_" . date('Y') . ".txt", "r");
                while (!feof($file)) {
                    $line = fgets($file);
                    $id = substr($line, 0, strpos($line, ":"));
                    if ($id == $i[0]) {
                        $cons = substr($line, strpos($line, ":") + 1);

                        if ($cons == $i[1]) $trust++;
                    }
                }
            }
        }
        return $trust;
    }
    public function tauxClientTrust()
    {
        $nbClient = $this->nbClientAjouter();
        $trust = $this->nbClientTrust();
        return round($trust / $nbClient, 2);
    }

    /// pourcentage ch7al dles clients ki3amro les donnees s7a7en ---------


}
