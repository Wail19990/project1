<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content reclamation-client">

        <form action="" method="POST">
            <center>
                <h2>Envoyer votre reclamation</h2>
            </center>

            <?php
            if (isset($_GET['send'])) {
                if ($_GET['send'] == 'success') {
                    echo '  <div class="error_display">
                                    <p>Votre reclamation est bien enregistrée</p>
                                </div>';
                }
            }
            ?>

            <div class="form_input">
                <input type="text" name="objet" required>
                <label>
                    <span>Objet</span>
                </label>
            </div>
            <div class="form_input form_textarea">
                <textarea name="reclamation" cols="35" rows="6" required></textarea>
                <label>
                    <span>Reclamation</span>
                </label>
            </div>
            <input type="submit" name="envoyer" value="Envoyer"><br>

        </form>
    </div>
</div>
</div>

<?php
if (isset($_POST['envoyer'])) {
    if (!empty($_POST['objet']) && !empty($_POST['reclamation'])) {
        $c->reclamer($_SESSION['username'], $_POST['objet'], $_POST['reclamation']);
    }
}
?>

<script src="../script/main.js"></script>
</body>
</html>