<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content consomation-client">

        <form action="" method="POST">
            <center>
                <h2> Ajouter votre consommation mensuelle </h2>
            </center>
            <?php
            if (isset($_GET['add'])) {
                if ($_GET['add'] == 'failed') {
                    echo '  <div class="error_display">
                                        <p>numéro de compteur est inferieur au mois précédent</p>
                                    </div>';
                }
            }
            if (isset($_GET['addDate'])) {
                if ($_GET['addDate'] == 'failed') {
                    echo '  <div class="error_display">
                                        <p>Cette date est déja existe</p>
                                    </div>';
                }
            }
            ?>
            <div class="form_input">
                <input type="text" name="consomation" required>
                <label>
                    <span>Consomation</span>
                </label>
            </div>
            <div class="form_input">
                <input type="date" name="consomationDate" required>
                <label>
                    <span>Date of consomation</span>
                </label>
            </div>
            <input type="submit" name="ajouter" value="Ajouter"><br>

        </form>
    </div>
</div>
</div>
<?php

if (isset($_POST['ajouter'])) {
    if (!empty($_POST['consomation'])) {
        $date = date('m/d/Y');
        if (!empty($_POST['consomationDate']))
            $date = $_POST['consomationDate'];

       $c->ajouterConsomation($_SESSION['username'], $date, $_POST['consomation']);
    }
}
?>

<script src="../script/main.js"></script>
</body>
</html>