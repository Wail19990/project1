<?php
$month = [
    "01" => "Janvier",
    "02" => "Fevrier",
    "03" => "Mars",
    "04" => "Avril",
    "05" => "Mai",
    "06" => "Juin",
    "07" => 'Juillet',
    "08" => "Aout",
    "09" => "Septembre",
    "10" => "Octobre",
    "11" => "Novembre",
    "12" => "Decembre"
];

include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">
        <div class="dash-content">

            <div class="alert-fact">
                <div class="symbol">
                    <i class="fas fa-exclamation"></i>
                </div>
                <div class="alert-data">
                    <h4>Facture non regle</h4>
                    <p><?php echo $bd->countFacture($_SESSION['username']) ?></p>
                </div>
            </div>

            <div class="elements">
                <div class="scare-element">
                    <div class="symbol">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h4>Consomation Mensuelle</h4>
                    <div class="scare-data">
                        <p> <?php echo $bd->consommationMensuel($_SESSION['username']) ?> KW/h</p>
                        <?php if ($bd->TauxConsommationMensuel($_SESSION['username']) >= 0) { ?>
                            <p>
                                <i class="fas fa-arrow-alt-circle-up red"></i>
                                <span class="red"> <?php echo '+' . $bd->TauxConsommationMensuel($_SESSION['username']) ?> KW/h</span>
                            </p>
                        <?php } else { ?>
                            <p>
                                <i class="fas fa-arrow-alt-circle-down green"></i>
                                <span class="green"><?php echo $bd->TauxConsommationMensuel($_SESSION['username']) ?> KW/h</span>
                            </p>
                        <?php } ?>
                    </div>
                </div>

                <div class="scare-element">
                    <div class="symbol">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h4>Consomation anuelle</h4>
                    <div class="scare-data">
                        <p><?php echo $bd->consommationAnuelle($_SESSION['username']) ?> KW/h</p>

                        <?php if ($bd->TauxConsommationAnnuel($_SESSION['username']) >= 0) { ?>

                            <p>
                                <i class="fas fa-arrow-alt-circle-up red"></i>
                                <span class="red"><?php echo '+' . $bd->TauxConsommationAnnuel($_SESSION['username']) ?> KW/h</span>
                            </p>
                        <?php } else { ?>
                            <p>
                                <i class="fas fa-arrow-alt-circle-down green"></i>
                                <span class="green"><?php echo $bd->TauxConsommationAnnuel($_SESSION['username']) ?> KW/h </span>
                            </p>
                        <?php } ?>
                    </div>
                </div>

                <div class="scare-element">
                    <div class="symbol">
                        <i class="fas fa-calculator"></i>
                    </div>
                    <h4>Calculez</h4>
                    <div class="scare-data">
                        <div class="calc-form">
                            <p>Votre consomation (KW/h)</p>
                            <input id="consomation" type="text" placeholder="Votre consomation..">
                            <p>Montant a payer</p>
                            <input id="montant" type="text" readonly>
                        </div>

                    </div>
                </div>
            </div>
            <div class="dashboard-second">

                <div class="chart">
                    <div class="chart-title">
                        <h3>La consommation mensuelle</h3>
                    </div>

                    <div id="chart">
                        <?php
                        $result = $bd->chart($_SESSION['username']);
                        $chart_data = '';

                        foreach (array_reverse($result) as $row)
                            $chart_data .= "{ month:'" . $month[substr($row[0], 5, 2)] . "',consomation:" . $row[1] . "}, ";
                            if(!empty($chart_data))
                                $chart_data = substr($chart_data, 0, -1);
                            else
                                echo "<div class='chart-title'>
                                        <i class='fas fa-info-circle'></i>
                                        <h2>Pas assez des données pour le moment.</h2>
                                    </div>"
                        ?>
                    </div>
                </div>

                <div class="prices">
                    <h3>Les prix d'electriciteé par tranche (TVA : 14%) </h3>
                    <hr>

                    <div class="price-item">
                        <div class="price-title">
                            <h3>Tranche 1 </h3>
                            <span>Entre 0 kwh et 100 kwh</span>
                        </div>
                        <p><i class="fas fa-times"></i> 0.91 dh</p>
                    </div>

                    <div class="price-item">
                        <div class="price-title">
                            <h3>Tranche 2 </h3>
                            <span>Entre 100 kwh et 200 kw</span>
                        </div>
                        <p><i class="fas fa-times"></i> 1.01 dh</p>
                    </div>

                    <div class="price-item">
                        <div class="price-title">
                            <h3>Tranche 3 </h3>
                            <span>Plus que 200 kwh</span>
                        </div>
                        <p><i class="fas fa-times"></i> 1.12 dh</p>
                    </div>

                </div>
            </div>
        </div>
    </div>

</div>
</div>

<script>
    Morris.Bar({
        element: 'chart',
        data: [<?php echo $chart_data; ?>],
        xkey: 'month',
        ykeys: ['consomation'],
        labels: ['consomation'],
        hideHover: 'auto',
        stacked: true
    });
</script>

<script src="../script/main.js"></script>
</body>

</html>