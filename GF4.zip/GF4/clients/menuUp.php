<div class="menuUp">
    <div class="menuRes">
         <div class="menuBars">
            <i class="fas fa-bars"></i>
        </div>
        <div class="user">
            <i class="fas fa-user"></i>
            <span><?php $bd->ClientName($_SESSION['username']); ?></span>
        </div>
    </div>
   
    <div class="logout">
        <a href="logout.php">
            <span>Logout</span>
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </div>
</div>