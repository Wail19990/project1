<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">


        <div class="facture">
            <center>
                <h2>Table des factures</h2>
            </center>
            <div class="table">

                <table>
                    <tr>
                        <th style="width: 100px;">N.facture</th>
                        <th>Date</th>
                        <th>Consommation</th>
                        <th>Prix HT</th>
                        <th>Prix TTC</th>
                        <th>Statut</th>
                        <th style="width: 80px;">Telecharger</th>
                    </tr>
                   
                    <?php
                    $bd->showFacture($_SESSION['username']);
                    ?>

                </table>
            </div>

        </div>

    </div>

</div>
</div>

<script src="../script/main.js"></script>
</body>
</html>
