<?php 
class agents{

    private $nom;
    private $prenom;
    private $cin;
    private $email;
    private $telephone;

    //construct
    public function __construct()
    {
    }

    //getters

    public function getNom()
    {
        return $this->nom;
    }
    public function getPrenom()
    {
        return $this->prenom;
    }

    public function getCin()
    {
        return $this->cin;
    }
    public function getEmail()
    {
        return $this->email;
    }
    //setters

    public function setNom($nom)
    {
        $this->nom = $nom;
        return $this;
    }
  
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
        return $this;
    }

    public function setCin($cin)
    {
        $this->cin = $cin;
        return $this;
    }

 
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;
    }

   
    public function setTelephone($telephone)
    {
        $this->telephone = $telephone;
        return $this;
    }

    //other functions

    public function ajouterClient($nom,$prenom,$cin,$email,$telephone)
    {
        $bd = new BD(); 
        $bd->insertClient($nom,$prenom,$cin,$email,$telephone);
    }

    public function modifierClient($cin,$nom,$prenom,$newCin,$email,$telephne)
    {
        $bd = new BD(); 
        $bd->updateClient($cin,$nom,$prenom,$newCin,$email,$telephne);
    }

    public function supprimerClient($cin)
    {
        $bd = new BD(); 
       // $bd->deleteContrat($cin);
        $bd->deleteClient($cin);
    }

    public function modifierStatutFacture($numFacture)
    {
        $bd = new BD();
        $bd->updateStatut($numFacture);

    }

    public function repondreAuReclamation($numReclamation,$cinAgent ,$reponse,$dateReponse)
    {
        $bd = new BD(); 
        $bd->updateReclamation($numReclamation,$cinAgent,$reponse,$dateReponse);
        
    }

    public function ajouterFichierCA()
    {   
        if(substr($_FILES["consomation"]["name"],-4) == ".txt"){
            if(move_uploaded_file($_FILES["consomation"]["tmp_name"], "../docs/consomation_" .date('Y').".txt"))
                echo "<script>window.location='consomation.php?addFile=success'</script>";
            
            return true;
        }
        else
            return false;
    }

    
}