<?Php
require('fpdf/fpdf.php');

if(isset($_POST['down']))
{
$numFact = $_POST['numFact'];
$dateFact=$_POST['dateFact'];
$numCont =$_POST['numCont'];
$nom =$_POST['nom'];
$prenom=$_POST['prenom'];
$cons =$_POST['cons'];
$prix=$_POST['prix'];


$pdf = new FPDF();
$pdf->AddPage();
$pdf->AddFont('Times');
$pdf->AddFont('Timesb');
$pdf->Image('assets/logo.png',10,20,40,40);

$pdf->SetFont('Timesb','',36);
$pdf->SetFillColor(157, 215, 239); 
$yourtext = iconv('UTF-8', 'windows-1252', "Facture d'Electricité");
$pdf->SetTextColor(28, 78, 128);
$pdf->Cell(200,60,$yourtext,0,1,'C',false);

$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Times','',14);
$pdf->SetLeftMargin(25);
$pdf->Cell(100,15,"Numero de la facture",'B',0,'L',true);
$pdf->Cell(60,15,$numFact,'B',1,'L',true);

$pdf->Cell(100,15,"Date de la facture ",'B',0,'L',false);
$pdf->Cell(60,15,$dateFact,'B',1,'L',false);

$pdf->Cell(100,15,"Numero du contrat ",'B',0,'L',true);
$pdf->Cell(60,15,$numCont,'B',1,'L',true);

$pdf->Cell(100,15,"Nom ",'B',0,'L',false,);
$pdf->Cell(60,15,$nom,'B',1,'L',false);

$pdf->Cell(100,15,"Prenom ",'B',0,'L',true);
$pdf->Cell(60,15,$prenom,'B',1,'L',true);

$pdf->Cell(100,15,"Consomation ",'B',0,'L',false,);
$pdf->Cell(60,15,$cons,'B',1,'L',false);

$pdf->Cell(100,15,"Prix ",'B',0,'L',true);
$pdf->Cell(60,15,$prix,'B',1,'L',true);



$pdf->Output('facture_C'.$numCont.'_F'.$numFact.'.pdf','D',true); // Send to browser and display
}?>