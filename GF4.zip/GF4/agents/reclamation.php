<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">


        <div class="reclamation">
            <center>
                <h2>Table des reclamations</h2>
            </center>
            <div class="table">

                <table>
                    <tr>
                        <th>Contrat n°</th>
                        <th>Object</th>
                        <th>Plainte</th>
                        <th>Date Reclamation</th>
                        <th style="width: 80px;">Statut</th>
                        <th style="width: 80px;">Repondre</th>
                    </tr>
                   
                    <?php
                        $bd->showReclamation($_SESSION['username']);
                    ?>
                    
                </table>
            </div>

        </div>

    </div>

</div>
</div>
<?php
if(isset($_POST["reply"])){
    if(!empty($_POST["numRec"])){
        $bd->updateReclamation($_POST["numRec"],$_SESSION["username"],date("Y-m-d"));
    }
}
if(isset($_GET['id']) && !empty($_GET["id"])){
    $bd->sendEmail($_GET['id']);
    unset($_GET['id']);
}
?>
<script src="../script/main.js"></script>

</body>
</html>