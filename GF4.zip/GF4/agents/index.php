<?php

$month = [
    "1" => "Janvier",
    "2" => "Fevrier",
    "3" => "Mars",
    "4" => "Avril",
    "5" => "Mai",
    "6" => "Juin",
    "7" => 'Juillet',
    "8" => "Aout",
    "9" => "Septembre",
    "10" => "Octobre",
    "11" => "Novembre",
    "12" => "Decembre"
];

include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">
        <div class="dash-content">

            <div class="alert-fact">
                <div class="symbol">
                    <i class="fas fa-exclamation"></i>
                </div>
                <div class="alert-data">
                    <h4>Reclamation non reglé</h4>
                    <p><?php echo $bd->countReclamation() ?></p>
                </div>
            </div>

            <div class="elements">
                <div class="scare-element">
                    <div class="symbol">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <h4>Client Ajoutes</h4>
                    <div class="scare-data">
                        <p> <?php echo $bd->nbClientAjouter() ?></p>

                    </div>
                </div>

                <div class="scare-element">
                    <div class="symbol">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <h4>Taux des donnees correctes</h4>
                    <div class="scare-data">
                        <p><?php echo $bd->tauxClientTrust() ?>%</p>
                    </div>
                </div>

                <div class="calendar-element">
                    <div id="color-calendar"></div>
                </div>
            </div>
            <div class="dashboard-second">

                <div class="chart-agent">
                    <div class="chart-title">
                        <h3>Le nombre de réclamation par mois</h3>
                    </div>
                    <div id="chart">
                        <?php
                        $result = $bd->chartNumeroReclamation();
                        $chart_data = '';

                        $m = date('m');
                        $j = 0;
                        $rec = 0;

                        for ($i = $m + 1; $i <= $m + 12; $i++) {
                            //echo $result[$j][0];
                            if ($result[$j][0] == $i % 12) {
                                $rec = $result[$j][1];
                                $j++;
                            } else
                                $rec = 0;


                            if ($i == 12)
                                $chart_data .= "{ month:'" . $month[12] . "',reclamation:" . $rec . "}, ";

                            else
                                $chart_data .= "{ month:'" . $month[$i % 12] . "',reclamation:" . $rec . "}, ";
                        }
                        if (!empty($chart_data))
                            $chart_data = substr($chart_data, 0, -1);
                        else
                            echo "<div class='chart-title'>
                                        <i class='fas fa-info-circle'></i>
                                        <h2>Pas assez des données pour le moment.</h2>
                                    </div>"
                        ?>
                    </div>
                </div>


            </div>
        </div>
    </div>

</div>
</div>

<script>
    Morris.Bar({
        element: 'chart',
        data: [<?php echo $chart_data; ?>],
        xkey: 'month',
        ykeys: ['reclamation'],
        labels: ['nb de reclamation'],
        hideHover: 'auto',
        stacked: true
    });
</script>

<script src="../script/main.js"></script>


</body>

</html>