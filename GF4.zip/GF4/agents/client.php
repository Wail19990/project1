<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">

        <div class="client">
            <?php
            if (!( (isset($_GET['add']) && ($_GET['add'] == 'start')) || (isset($_GET['update'])  && ($_GET['update'] == 'start')))) { ?>
                <center>
                    <h2>Table des Clients</h2>
                </center>
                <?php
                if (isset($_GET['add'])) {
                    if ($_GET['add'] == 'success') {
                        echo '  <div class="error_display" id="error">
                                    <i class="fas fa-times" id="close-error"></i>
                                    <p>Le client est bien enregistrée</p>
                                </div>';
                    }
                }

                if (isset($_GET['update'])) {
                    if ($_GET['update'] == 'success') {
                        echo '  <div class="error_display" id="error">
                                <i class="fas fa-times" id="close-error"></i>
                                <p>Le client est bien modifiees</p>
                            </div>';
                    }
                }
                ?>
                <a href="client.php?add=start"><i class="fas fa-user-plus"></i>Ajouter un client</a>

                <div class="table">
                    <table>
                        <tr>
                            <th style="width: 100px;">CIN</th>
                            <th>Nom</th>
                            <th>Prenom</th>
                            <th>Email</th>
                            <th>Tel</th>
                            <th style="width: 80px;">Modifier</th>
                            <th style="width: 80px;">Supprimer</th>
                        </tr>

                        <?php
                        $bd->showClient();
                        ?>

                    </table>
                </div>

            <?php
            }
            if (isset($_GET['add']) && $_GET['add'] == 'start') { ?>
                <form method="POST" action="" class="client-form">
                    <center>
                        <h2>Ajouter un client</h2>
                    </center>

                    <div class="form_input">
                        <input type="text" name="CIN" required>
                        <label>
                            <span>CIN</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="nom" required>
                        <label>
                            <span>Nom</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="prenom" required>
                        <label>
                            <span>Prenom</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="email" name="email" required>
                        <label>
                            <span>Email</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="tel" required>
                        <label>
                            <span>Telephone</span>
                        </label>
                    </div>

                    <input type="submit" name="ajouter" value="Ajouter"><br>

                </form>

            <?php
            }
            if (isset($_GET['update']) && $_GET['update'] == 'start') {
                $client = $bd->showClientId($_GET['id']);
            ?>
                <form method="POST" class="client-form">
                    <center>
                        <h2>Modifier un client</h2>
                    </center>

                    <div class="form_input">
                        <input type="text" name="CIN" value="<?php echo $client[2] ?>" required>
                        <label>
                            <span>CIN</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="nom" value="<?php echo $client[0] ?>" required>
                        <label>
                            <span>Nom</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="prenom" value="<?php echo $client[1] ?>" required>
                        <label>
                            <span>Prenom</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="email" name="email" value="<?php echo $client[3] ?>" required>
                        <label>
                            <span>Email</span>
                        </label>
                    </div>
                    <div class="form_input">
                        <input type="text" name="tel" value="<?php echo $client[4] ?>" required>
                        <label>
                            <span>Telephone</span>
                        </label>
                    </div>

                    <input type="submit" name="modifier" value="Modifier"><br>

                </form>
            <?php
            }

            ?>

        </div>

    </div>

</div>
</div>
<?php
if (isset($_POST['ajouter'])) {
    if (!empty($_POST['CIN']) && !empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['tel'])) {
        echo $_POST['CIN'];
        $a->ajouterClient($_POST['nom'], $_POST['prenom'], $_POST['CIN'], $_POST['email'], $_POST['tel']);
    }
}
if (isset($_POST['modifier'])) {
    $oldcin = $_GET['id'];
    if (!empty($_POST['CIN']) && !empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST['email']) && !empty($_POST['tel'])) {
        $a->modifierClient($oldcin, $_POST['nom'], $_POST['prenom'], $_POST['CIN'], $_POST['email'], $_POST['tel']);
    }
}
if (isset($_POST['delete'])) {
    $a->supprimerClient($_POST['cin']);
}
?>
<script src="../script/main.js"></script>

</body>

</html>