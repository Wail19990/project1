<?php


include("../header.php");
if (!isset($_SESSION['username']))
    header('location:../login.php');
include("menu.php");
?>

<div class="main">
    <?php
    include("menuUp.php");
    ?>
    <div class="main-content">
        <div class="consomation">
            <center>
                <h2>Table des consomations</h2>
            </center>

            <?php
            if (isset($_GET['addFile'])) {
                if ($_GET['addFile'] == 'success') {
                    echo '  <div class="error_display" id="error">
                                <i class="fas fa-times" id="close-error"></i>
                                <p>Le fichier de consomation est telecharge avec success</p>
                            </div>';
                }
            }
            ?>
            <form action="" method="POST" enctype="multipart/form-data">

                <input type="file" name="consomation" accept=".txt" required>
                <input type="submit" name="ajouter" value="Ajouter">

            </form>

            <div class="table">

                <table>
                    <tr>
                        <th style="width: 120px;">Num. contrat</th>
                        <th>Cos. annuelle</th>
                        <th>Cos. réel</th>
                        <th style="width: 80px;">Statut</th>
                    </tr>

                    <?php
                    $bd->showConsomation();
                    ?>

                </table>
            </div>

        </div>

    </div>
</div>
</div>
<?php

if (isset($_POST['ajouter'])) {

    if ($a->ajouterFichierCA()) {
        echo "yes";
    }
}
?>

<script src="../script/main.js"></script>


</body>

</html>