<div class="container">

    <div class="menu closeMenu">
        <div class="menuTimes">
            <i class="fas fa-times"></i>
        </div>

        <span>
            <img src="../assets/logo.png" alt="logo">
            <div class="logo-title">
                <span>Gestion Facture</span><br>
                <span>Electricite</span>
            </div>
        </span>

        <div class="menuItem">
            <ul>
                <li>
                    <i class="fas fa-tachometer-alt"></i>
                    <a href="index.php">Acceuil</a>
                </li>
                <li>
                    <i class="fas fa-user"></i>
                    <a href="client.php">Client</a>
                </li>
                <li>
                    <i class="fas fa-meteor"></i>
                    <a href="consomation.php">Consomation</a>
                </li>
                <li>
                    <i class="fas fa-comment-dots"></i>
                    <a href="reclamation.php">Reclamation</a>
                </li>
            </ul>
        </div>

    </div>