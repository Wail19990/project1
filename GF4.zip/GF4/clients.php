<?php

class clients{

    
    private $nom;
    private $prenom;
    private $cin;
    private $email;
    private $telephone;

   // construct
    public function __construct()
   {
   }
   
    //getters
    public function getNom()
    {
        return $this->nom;
    }


    public function getPrenom()
    {
        return $this->prenom;
    }

    public function getCin()
    {
        return $this->cin;
    }

    public function getEmail()
    {
        return $this->email;
    }

      
    public function getTelephone()
    {
        return $this->telephone;
    }
    //setters

    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

  
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    
    public function setCin($cin)
    {
        $this->cin = $cin;

        return $this;
    }

    
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

 
    public function setTelephone($telephone)
    {
        $this->telephone = $telephone;

        return $this;
    }

    //other functions

    //reclamer
    public function reclamer($num_contrat,$objet,$message)
    {
        $bd = new BD(); 
        $bd->insertReclamation($num_contrat,$objet,$message);
    }

    //ajouter consommation

    public function ajouterConsomation($num_contrat,$date,$num_compteur)
    {
        $bd = new BD(); 
        $bd->insertFacture($num_contrat,$date,$num_compteur);
    }

}