

var menuBars = document.querySelector(".menuBars");
var menu = document.querySelector(".menu");
var menuClose = document.querySelector(".menuTimes");

if (menuBars) {
    menuBars.addEventListener("click", function () {
        menu.classList.toggle("openMenu");
        menu.classList.toggle("closeMenu");
    });
}

if (menuClose) {
    menuClose.addEventListener("click", function () {
        menu.classList.toggle("openMenu");
        menu.classList.toggle("closeMenu");
    });
}


//calculator
var montant = document.getElementById('montant');
var consomation = document.getElementById('consomation');

if (consomation) {
    consomation.addEventListener('keyup', function () {

        var c = consomation.value;
        var prixHT = 0;
        if (c <= 100)
            prixHT = 0.91 * c;
        else {
            if (c <= 200)
                prixHT = 1.01 * c;
            else
                prixHT = 1.12 * c;
        }

        montant.value = Math.round(prixHT * 1.14 * 100) / 100;
    });
}

//close message
var closeBtnError = document.getElementById("close-error");
var errorMessage = document.getElementById("error");

if (closeBtnError) {
    closeBtnError.addEventListener("click", function () {
        errorMessage.style.display = "none";
    });
}



// affichage des factures
var modal = document.getElementsByClassName("modal-container");
var closeModal = document.getElementsByClassName("closeFacture");
var showModal = document.getElementsByClassName("showFacture");

if (showModal) {
    for (var i = 0; i < showModal.length; i++) {
        showModal[i].addEventListener("click", function (e) {
            var target = e.target;
            modal[target.getAttribute("show")].classList.toggle("fadeIn");
            modal[target.getAttribute("show")].classList.toggle("fadeOut");
        });

        closeModal[i].addEventListener("click", function (e) {
            var target = e.target;
            modal[target.getAttribute("show")].classList.toggle("fadeIn");
            modal[target.getAttribute("show")].classList.toggle("fadeOut");
        });

    }
}

//adaptation hauteur de menu au page
window.onload = function () {
    document.querySelector(".menu").style.minHeight = Math.max(document.body.scrollHeight, document.body.offsetHeight,
    document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)+'px';
}
window.onresize = function(){
    document.querySelector(".menu").style.minHeight = Math.max(document.body.scrollHeight, document.body.offsetHeight,
    document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)+'px';
};
//calendar
const myEvents = [
    {
      start: '2022-01-01',
      end: '2022-01-01',
      name: 'fichier de consomation ',
      desc: 'Ajouter le fichier de consomation anuelle pour fixer les erreurs au niveau des donnees',
      // more key value pairs here
    },
];

new Calendar({
    id: '#color-calendar',
    eventsData: myEvents,
    // small or large
    calendarSize: 'small',
    
    // basic | glass
    theme: 'glass',

    // custom colors
    primaryColor: '#0091D5',
    headerColor: 'white',
    headerBackgroundColor: '#0091D5',

    // border radius
    borderRadius: '0.5rem',
});

//affichage du modal pour l'ajout de fichier de consoamtion
var today = new Date();

if(today.getMonth()+1 === 1 && today.getDate() === 1){
    alert("Ajouter le fichier de consommation anuelle "+today.getFullYear());
}