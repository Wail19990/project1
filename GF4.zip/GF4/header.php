<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- link to the our style -->
    <link rel="stylesheet" href="../style/styleClient.css" type="text/css">
    <link rel="stylesheet" href="../style/styleAgent.css" type="text/css">
    <link rel="stylesheet" href="style/login.css" type="text/css">
    <!-- link to the our style -->

    <!-- link to the icons font aweosme -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.css" rel="stylesheet">
    <!-- link to the icons font aweosme -->

    <!-- link to the calendar -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/color-calendar/dist/css/theme-basic.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/color-calendar/dist/css/theme-glass.css" />
    <script src="https://cdn.jsdelivr.net/npm/color-calendar/dist/bundle.min.js"></script>
    <!-- link to the calendar -->

    <!-- link to jquery -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <!-- link to jquery -->

    <!-- link to the graph -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <!-- link to the graph -->
    <title>Gestion des factures</title>
</head>

<body>
    <?php
    include("BD.php");
    include("clients.php");
    include("agents.php");

    session_start();
    $bd = new BD();
    $c = new clients();
    $a = new agents();
    ?>